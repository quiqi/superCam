import multiprocessing
import multiprocessing.queues
import time
import typing
from typing import Optional

from sympy.parsing.sympy_parser import _T

import pipeline.core
import pipeline.utils
import pipeline.log

logger = pipeline.log.Log.get_log()


class MulSource(pipeline.core.Worker):
    def __init__(self):
        super().__init__(name='_MulSource')

    def after_process(self, frame: pipeline.core.Frame):
        """
        用于阻塞进程
        :param frame:
        :return:
        """
        return frame


class MulIgnition:
    def __init__(self, dots: typing.List[pipeline.core.Node], queue_size: int = 10):
        if len(dots) == 0:
            raise Exception('Please include at least one node in nodes')

        self.pipes = {}
        self.process_list = {}
        self.source = []
        self.queue_size = queue_size

        # 初始化管道
        for dot in dots:
            if dot.name in ['_SOURCE', '_OUTPUT']:  # node 不可以以 '_SOURCE' 命名
                raise Exception('The node can not named as "_SOURCE"! Please changing the name.')
            if dot.name not in self.pipes.keys():
                self.pipes[dot.name] = multiprocessing.Queue(queue_size)  # 为当前进程建立管道

                # 如果该进程为源头进程
                if dot.source is not None:  # 如果该dot是源头dot，则
                    if dot.source == dot.name:  # 如果dot名和起始节点同名，则将节点名加入 source 列表中
                        self.source.append(dot.name)
                    else:  # 否则将多级路径加入 source 列表中
                        self.source.append('{}/{}'.format(dot.name, dot.source))
            else:
                raise Exception('Two processes with the same name appear: {}.'
                                'Processes cannot have the same name'.format(dot.name))
        self.pipes['_OUTPUT'] = multiprocessing.Queue(queue_size)
        self.pipes['_INPUT'] = multiprocessing.Queue(queue_size)
        if len(self.source) == 0:
            self.source.append(dots[0].name)
        # 加入源头进程，一切的数据包都来源于源头进程
        source_dot = pipeline.core.Node('_SOURCE', subsequents=self.source, worker=MulSource())
        p = MulIgnition.MulDot(source_dot, self.pipes)
        # p.start()
        self.process_list['_SOURCE'] = p

        # 初始化进程
        for dot in dots:
            p = MulIgnition.MulDot(dot, self.pipes)
            # p.start()
            self.process_list[dot.name] = p  # 为当前进程创造进程对象

    def run(self):
        for process in self.process_list:
            self.process_list[process].start()
        self.api()

    def api(self):
        time.sleep(2)
        print('The program has started and you can view the log information in log.py')
        print('You can input in this box to realize some interactive simply with process ')
        print('show -show the condition of pipe.')
        print('nodei _sub sub1 sub2... -change the subsequence of nodei to [sub1, sub2, ...]')
        print('nodei _close -close the nodei')
        print('nodei _open -open the node1')
        print('nodei show e -show the element e in worker of node1')
        print('nodei change e:v -change the value of element e in worker of node1 to v')
        while True:
            raw_order = input()
            order = raw_order.replace('\\', '').split(' ')
            if self.my_aip():
                continue    # 如果 my_api中命中，则不再执行之后的指令
            if len(order) == 1:
                if order[0] == 'show':
                    for p in self.pipes:
                        print('\t{}:{}/{}'.format(p, self.pipes[p].qsize(), self.queue_size))
            elif len(order) >= 2:
                order_rout = '_SOURCE/' + order[0]
                order_head = order[1]
                order_args = order[2:]
                order_frame = pipeline.core.OrderFrame(order_head, order_args, '_INPUT', order_rout)
                order_frame.data['raw_order'] = raw_order
                self.pipes['_INPUT'].put(order_frame)
                print('{} already send out'.format(raw_order))
            else:
                print('Unrecognized command:{}'.format(' '.join(order)))

    def get(self):
        if self.pipes['_OUTPUT'].empty():
            return None
        return self.pipes['_OUTPUT'].get()

    def my_aip(self):
        return False

    class MulDot(multiprocessing.Process):
        def __init__(self, node: pipeline.core.Node, pipes: dict):
            super(MulIgnition.MulDot, self).__init__(name=node.name)
            self.node = node
            self.pipes = pipes

        def run(self):
            if self.node.name == '_SOURCE':  # 如果是源头节点，则自己生成数据
                while self.node.switch:
                    if self.pipes['_INPUT'].empty():
                        frames = self.node.run(pipeline.core.Frame(end='_SOURCE'))
                    # 如果不为空，则读取命令
                    else:
                        frames = self.node.run(self.pipes['_INPUT'].get())
                    # print('s:{}'.format(frames[0].end))
                    for frame in frames:
                        if frame.end in self.pipes.keys():  # 安全检查，检查frame当前帧的目的地是否有对应的管道
                            try:
                                if isinstance(frame, pipeline.core.OrderFrame):
                                    self.pipes[frame.end].put(frame)    # 如果是命令帧，不能被丢弃
                                else:
                                    self.pipes[frame.end].put(frame, timeout=0.005)  # 如果有，则将当前帧放入管道中
                            except Exception as e:
                                pass    # 超过 0.005秒则直接跳过这条管道
                        else:
                            pass  # 否则什么也不干，相当于抛弃这个帧
            else:
                while self.node.switch:  # 如果是非源头节点，则直接从自己的管道中读取数据
                    frame = self.pipes[self.node.name].get()
                    if frame is not None:
                        frames = self.node.run(frame)
                        # print('d:{} run, data:{}'.format(self.node.name, frames[0].data))
                        for frame in frames:  # 按地址发送每一个帧
                            if frame.end in self.pipes.keys():  # 安全检查，检查frame当前帧的目的地是否有对应的管道
                                if isinstance(frame, pipeline.core.OrderFrame):
                                    self.pipes[frame.end].put(frame)  # 如果是命令帧，不能被丢弃
                                else:
                                    try:
                                        self.pipes[frame.end].put(frame, timeout=0.005)  # 如果有，则将当前帧放入管道中
                                    except Exception as e:
                                        pass
                            else:
                                while self.pipes['_OUTPUT'].full():
                                    self.pipes['_OUTPUT'].get()
                                self.pipes['_OUTPUT'].put(frame)
                                # print(self.pipes['_OUTPUT'].qsize())
                                # print(self.node.name)
