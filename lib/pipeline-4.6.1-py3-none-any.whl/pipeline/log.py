import logging
import os
import time


class Log:
    logger = logging.getLogger('pipeline')
    logger.setLevel(logging.DEBUG)  # 默认级别为 debug
    formatter = logging.Formatter('%(asctime)s|%(levelname)-8s|%(filename)-10s:%(lineno)-5s|%(message)s')

    # 文件输出句柄
    if not os.path.exists('./log'):
        os.makedirs('./log')
    file_handler = logging.FileHandler(filename='log/pipe_log.log', mode='a')
    file_handler.setLevel(logging.INFO)
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)

    # 命令行输出句柄
    # if is_print:
    #     console_handler = logging.StreamHandler()
    #     console_handler.setLevel(logging.DEBUG)
    #     console_handler.setFormatter(formatter)
    #     self.logger.addHandler(console_handler)

    @staticmethod
    def get_log():
        return Log.logger









